# Préparer l'APK Android — NERF SCORE

Le projet web est préparé pour être empaqueté avec Capacitor.

## Prérequis
- Node.js 20+
- Android Studio avec Android SDK installé
- JDK 17 (ou la version demandée par la version de Gradle installée)

## Générer le projet Android et l'APK
Depuis ce dossier :

```bash
npm install
npm install @capacitor/android@^7.4.3
npx cap add android
npm run cap:sync
npx cap open android
```

Dans Android Studio : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
L'APK debug est normalement généré dans `android/app/build/outputs/apk/debug/`.

Pour compiler en ligne de commande après génération du dossier Android :

```bash
cd android
./gradlew assembleDebug
```

## Caméra et microphone
NERF SCORE utilise `getUserMedia` pour la caméra et le microphone. Il faudra tester les
autorisations caméra/micro sur un vrai appareil Android. Le SDK Android et Android Studio
sont nécessaires pour produire et signer un APK.

## Identité Android
- Application : NERF SCORE
- Identifiant : `fr.nerfscore.app`


## Compilation automatique (sans Android Studio local)

Le dépôt contient maintenant `.github/workflows/build-android-apk.yml`. Après avoir envoyé
ce projet sur GitHub, ouvrir **Actions → Build Android APK → Run workflow**. À la fin,
télécharger l'artefact `nerf-score-debug-apk` : il contient `app-debug.apk`.
