import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'fr.nerfscore.app',
  appName: 'NERF SCORE',
  webDir: 'dist',
  server: { androidScheme: 'https' },
};

export default config;
